<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="Pokemon" tilewidth="16" tileheight="16" spacing="1" margin="1" tilecount="19080" columns="60">
 <image source="DS DSi - Pokemon Black White - Old-Gen Overworld Pokemon.png" width="1024" height="5408"/>
</tileset>
