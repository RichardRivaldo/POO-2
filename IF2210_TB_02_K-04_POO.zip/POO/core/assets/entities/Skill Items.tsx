<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="Skill Items" tilewidth="16" tileheight="16" spacing="1" margin="1" tilecount="15720" columns="120">
 <image source="Nintendo Switch - Fire Emblem Three Houses - Inventory Weapon Skill &amp; Ability Icons.png" width="2048" height="2233"/>
</tileset>
