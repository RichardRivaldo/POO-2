<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="Map" tilewidth="16" tileheight="16" spacing="1" margin="1" tilecount="420" columns="30">
 <image source="Map 1.png" width="512" height="244"/>
</tileset>
