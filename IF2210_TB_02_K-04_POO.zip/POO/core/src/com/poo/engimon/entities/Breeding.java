package com.poo.engimon.entities;

public interface Breeding {
    public Engimon breed(Engimon thisEngimon, Engimon anotherEngimon, String nama);
}