package org.json.simple;

//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

public interface JSONAware {
    String toJSONString();
}
