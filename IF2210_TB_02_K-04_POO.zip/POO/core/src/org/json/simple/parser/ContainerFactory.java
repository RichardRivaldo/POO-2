//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package org.json.simple.parser;

import java.util.List;
import java.util.Map;

public interface ContainerFactory {
    Map createObjectContainer();

    List creatArrayContainer();
}
