# POO
Tugas Besar 2 PBO 2020/2021 K4 Kelompok 2

### How to Run
* Lakukan `Build Gradle` untuk project `POO`.
* Buat Configuration `Application` baru jika menggunakan `Intellij IDEA`. 
* Jalankan `POO.desktop.main` dan set kelas yang ingin dijalankan menjadi `com.poo.engimon.dekstop.DesktopLauncher`.
* Jalankan program dengan menggunakan `run`. 
* Gunakan keypress `h` untuk menampilkan daftar command yang tersedia di dalam permainan. 